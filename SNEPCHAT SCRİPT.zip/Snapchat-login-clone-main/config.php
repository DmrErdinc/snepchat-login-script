<?php
// Veritabanı bağlantı bilgileri
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'dmrerdin_snapchat_data');
define('DB_PASSWORD', '37711435Ee.');
define('DB_NAME', 'dmrerdin_snapchat_data');

// Veritabanı bağlantısını oluştur
function getDBConnection() {
    $conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
    
    if ($conn->connect_error) {
        die("Bağlantı hatası: " . $conn->connect_error);
    }
    
    return $conn;
}
?> 