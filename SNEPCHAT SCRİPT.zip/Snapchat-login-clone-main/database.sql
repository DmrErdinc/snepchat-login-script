-- Veritabanını oluştur
CREATE DATABASE IF NOT EXISTS snapchat_data;
USE snapchat_data;

-- Kullanıcı verileri tablosunu oluştur
CREATE TABLE IF NOT EXISTS user_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL
); 