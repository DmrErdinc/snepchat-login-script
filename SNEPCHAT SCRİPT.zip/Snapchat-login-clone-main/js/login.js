//login.html dosyasının scripti

// Form gönderimini kontrol et
document.getElementById('loginForm').addEventListener('submit', function(event) {
    const passwordInput = document.getElementById('password');
    const incorrectMessage = document.querySelector('.incorrect');
    
    // Şifre 8 karakterden az mı kontrol et
    if (passwordInput.value.length < 8) {
        event.preventDefault(); // Form gönderimini engelle
        incorrectMessage.style.display = 'block';  // Hata mesajını göster
        return false;  // Form gönderimini engelle
    } else {
        incorrectMessage.style.display = 'none';  // Şifre geçerliyse hata mesajını gizle
        return true;  // Form gönderimine izin ver
    }
});

// Şifre görünürlüğünü göster/gizle için dinamik resim ile değiştir
document.querySelector('.toggle-password').addEventListener('click', function () {
    const passwordField = document.getElementById('password');
    const eyeIcon = document.getElementById('eye-icon');
    
    if (passwordField.type === 'password') {
        passwordField.type = 'text';
        eyeIcon.src = 'img/eye-open.svg';  // Açık göz ikonuna güncelle
        this.title = 'Şifreyi Gizle';  // Buton başlığını güncelle
    } else {
        passwordField.type = 'password';
        eyeIcon.src = 'img/eye-closed.svg';  // Kapalı göz ikonuna güncelle
        this.title = 'Şifreyi Göster';  // Buton başlığını güncelle
    }
});

// Kullanıcı adı/e-posta ve telefon numarası arasında geçiş
const switchToPhone = document.getElementById('switch-to-phone');
const usernameInput = document.getElementById('username');
const label = document.querySelector('label[for="username"]');

switchToPhone.addEventListener('click', function () {
    if (label.textContent === 'KULLANICI ADI VEYA E-POSTA') {
        label.textContent = 'TELEFON NUMARASI';
        usernameInput.type = 'tel';
        usernameInput.placeholder = 'Telefon numaranızı girin';
        switchToPhone.textContent = 'E-posta kullan';
    } else {
        label.textContent = 'KULLANICI ADI VEYA E-POSTA';
        usernameInput.type = 'text';
        usernameInput.placeholder = 'Kullanıcı adı veya e-posta adresinizi girin';
        switchToPhone.textContent = 'Telefon numarası kullan';
    }
});

window.onload = function() {
    var errorMessage = document.getElementById('error-message');
    errorMessage.style.display = 'block'; // Mesajı göster
  
    // Kullanıcı sayfada herhangi bir yere tıkladığında hata mesajını gizle
    document.body.addEventListener('click', function() {
        errorMessage.style.display = 'none';
    });
};
  