// Sayfa tam olarak yüklendiğinde yükleyiciyi gizle
window.onload = function () {
    // Yükleyiciyi gizlemek için body'ye 'loaded' sınıfını ekle
    document.body.classList.add('loaded');
};