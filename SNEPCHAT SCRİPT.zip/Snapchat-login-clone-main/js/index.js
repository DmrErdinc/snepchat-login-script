  
  //index.html dosyasının scripti
  
  // Belirli bir gecikmeden sonra ana index sayfasına yönlendir (örn. 3 saniye)
  setTimeout(function() {
    window.location.href = "/Acconts.html"; // Ana index sayfanıza yönlendir
}, 2400); // 3000ms = 3 saniye






